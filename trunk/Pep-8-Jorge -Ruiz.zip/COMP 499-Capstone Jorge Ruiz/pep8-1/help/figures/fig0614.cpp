// File: fig0614.cpp
// Computer Systems, Fourth Edition
// Figure 6.14

#include <iostream>
using namespace std;

int main () {
   int j;
   for (j = 0; j < 3; j++) {
      cout << "j = " << j << endl; 
   }
   cout << "j = " << j << endl;
   return 0;
}
