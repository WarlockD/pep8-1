// Archivo: fig0521.cpp 
// Computer Systems, Cuarta Edición 
// Figura 5.21 

#include <iostream>
using namespace std;

char ch;
int j;

int main () {
   cin >> ch >> j;
   j += 5;
   ch++;
   cout << ch << endl << j << endl;
   return 0;
}
