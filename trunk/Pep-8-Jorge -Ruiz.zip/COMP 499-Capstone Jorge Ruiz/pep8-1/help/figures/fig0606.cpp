// Archivo: fig0606.cpp 
// Computer Systems, Cuarta Edición 
// Figura 6.6

#include <iostream>
using namespace std;

int main () {
   int numbero;
   cin >> numbero;
   if (numbero < 0) {
      numbero = -numbero;
   }
   cout << numbero;
   return 0;
}
