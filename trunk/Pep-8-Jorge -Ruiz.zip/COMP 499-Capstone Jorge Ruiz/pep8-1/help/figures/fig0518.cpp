// Archivo: fig0518.cpp 
// Computer Systems, Cuarta Edición 
// Figura 5.18

#include <iostream>
using namespace std;

int main () {
   cout << "Amor" << endl;
   return 0;
}
