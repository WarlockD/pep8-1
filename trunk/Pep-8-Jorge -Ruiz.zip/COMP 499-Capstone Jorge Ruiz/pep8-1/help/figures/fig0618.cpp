// File: fig0618.cpp
// Computer Systems, Fourth Edition
// Figure 6.18

#include <iostream>
using namespace std;

void printTri () {
   cout << "*" << endl;
   cout << "**" << endl;
   cout << "***" << endl;
   cout << "****" << endl;
}

int main () {
   printTri ();
   printTri ();
   printTri ();
   return 0;
}
