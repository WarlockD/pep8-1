// Archivo: fig0526.cpp 
// Computer Systems, Cuarta Edición 
// Figura 5.26


#include <iostream>
using namespace std;

const int bonus = 5;
int exam1;
int exam2;
int score;

int main () {
   cin >> exam1 >> exam2;
   score = (exam1 + exam2) / 2 + bonus;
   cout << "Calificación = " << score << endl;
   return 0;
}
