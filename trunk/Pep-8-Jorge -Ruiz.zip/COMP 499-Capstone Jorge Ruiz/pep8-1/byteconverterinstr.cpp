/*     
   Translated to Spanish:
   Jorge Ruiz 
   COMP 499
   CSU Channel Islands

   SPANISH
   -------------------------------------------------------------------------------------
   PEP8-1 es una máquina virtual para la escritura de lenguaje de máquina y el conjunto   
            
   Copyright (C) 2009 J. Stanley Warford, Pepperdine University      
   
   Este programa es software libre: usted puede redistribuirlo y / o modificarlo      
   bajo los términos de la Licencia Pública General de GNU según es publicada por      
   la Free Software Foundation, bien de la versión 3 de la Licencia, o      
   (a su elección) cualquier versión posterior.      
   
   Este programa se distribuye con la esperanza de que sea útil,      
   pero SIN NINGUNA GARANTÍA, incluso sin la garantía implícita de      
   COMERCIALIZACIÓN o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. Consulte la      
   GNU General Public License para más detalles.      
   
   Debería haber recibido una copia de la Licencia Pública General de GNU      
   junto con este programa. Si no es así, consulte <http://www.gnu.org/licenses/>.
*/

#include "byteconverterinstr.h"
#include "ui_byteconverterinstr.h"

#include "pep.h"
#include "sim.h"

ByteConverterInstr::ByteConverterInstr(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ByteConverterInstr)
{
    ui->setupUi(this);


}

ByteConverterInstr::~ByteConverterInstr()
{
    delete ui;
}

void ByteConverterInstr::setValue(int data)
{
    ui->label->setText(" " + Pep::enumToMnemonMap.value(Pep::decodeMnemonic[data])
                       + Pep::commaSpaceToAddrMode(Pep::decodeAddrMode[data]));
}

void ByteConverterInstr::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
